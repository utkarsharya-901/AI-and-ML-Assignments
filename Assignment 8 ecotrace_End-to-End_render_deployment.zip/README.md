# EcoTrace API Deployment

This repository contains the backend for the EcoTrace: Carbon Footprint Tracker, ready to be deployed as a web application on Render.

## How to Deploy

1. **GitHub**: Push this repository to GitHub.
2. **Render**: Create a new Blueprint on Render and connect your repository. Render will automatically read the `render.yaml` file and deploy the FastAPI service.
